CREATE DATABASE "K�T�PHANE_Bora�merB�l�k_200111035"

CREATE TABLE "kitapturleri" (
	"id"           INTEGER IDENTITY(1,1) PRIMARY KEY,
	"kitapturu"    TEXT,
);
CREATE TABLE "kullanicilar" (
	"id"	       INTEGER IDENTITY(1,1) PRIMARY KEY,
	"kullaniciadi" TEXT NOT NULL,
	"sifre"	       TEXT NOT NULL,
	"durum"	       INTEGER,
);
CREATE TABLE "kitaplar" (
	"id"                INTEGER IDENTITY(1,1) PRIMARY KEY,
	"barkodno"	        INTEGER,
	"kitapno"	        INTEGER,
	"kitapadi"	        TEXT,
	"kitapturuid"	    INTEGER FOREIGN KEY("kitapturuid") REFERENCES "kitapturleri"("id") ON UPDATE CASCADE,
	"kitapyazariadi"	TEXT,
	"kitapyazarisoyadi"	TEXT,
	"yayinevi"	        TEXT,
);
CREATE TABLE "sinifsube" (
	"id"	        INTEGER IDENTITY(1,1) PRIMARY KEY,
	"sinif"	        INTEGER,
	"�ube"	        TEXT,
);
CREATE TABLE "ogrenciler" (
	"id"	         INTEGER IDENTITY(1,1) PRIMARY KEY,
	"sinifsubeid"	 INTEGER FOREIGN KEY ("sinifsubeid") REFERENCES "sinifsube"("id") ON UPDATE CASCADE,
	"numara"	     INTEGER,
	"ogrenciad"	     TEXT,
	"ogrencisoyad"	 TEXT,
);
CREATE TABLE "emanetler" (
	"EMANET�d"	     INTEGER IDENTITY(1,1) PRIMARY KEY,
	"kitapid"	     INTEGER FOREIGN KEY ("kitapid") REFERENCES "kitaplar"("id") ON UPDATE CASCADE,
	"ogrencilerid"	 INTEGER FOREIGN KEY ("ogrencilerid") REFERENCES "ogrenciler"("id") ON UPDATE CASCADE,
	"alistarihi"	 DATETIME,
	"teslimtarihi"	 DATETIME,
	"aciklama"       TEXT,
);